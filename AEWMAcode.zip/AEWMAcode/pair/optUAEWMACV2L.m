function f=optUAEWMACV2L(n,lambda,k,L,CV0,arl0)
if L<=0
  f=100000;
else
  ARL0= ARLUAEWMACV2(n,lambda,L,k,CV0,CV0);
  f=(arl0-ARL0)/arl0;
end