function f=optUAEWMACVk(n,lambda,k,arl0,CV0,delta2)
if k<=0
  f=100000;
else
  options = optimset('TolX',1e-5);
  L0=3;
  CV1=CV0*delta2;
  L=fsolve(@(L)optUAEWMACV2L(n,lambda,k,L,CV0,arl0),L0,options);
  ARL1= ARLUAEWMACV2(n,lambda,L,k,CV0,CV1);
  ARL0=ARLUAEWMACV2(n,lambda,L,k,CV0,CV0);
  f=ARL1;
  Out=[lambda k L ARL1 ARL0];
  fprintf('lam=%6.4f k=%6.4f L=%6.4f ARL1=%6.4f ARL0=%6.1f \n',Out);
end