function [c,ceq] = confun(lambda,n,k,CV0,arl0,delta1)
CV1=CV0*delta1;
alpha=0.05;
L0=3;
options = optimset('TolX',1e-5);
Le=fsolve(@(L)ARLUEWMACV2(n,lambda,L,CV0,CV0)-arl0,L0,options);
ARLe=ARLUEWMACV2(n,lambda,Le,CV0,CV1);
La=fsolve(@(L)optUAEWMACV2L(n,lambda,k,L,CV0,arl0),L0,options);
ARLa=ARLUAEWMACV2(n,lambda,La,k,CV0,CV1);
c=ARLa-(1+alpha)*ARLe;
ceq=[];
end