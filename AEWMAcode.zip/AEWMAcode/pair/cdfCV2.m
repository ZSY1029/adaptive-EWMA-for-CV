function FCV2 = cdfCV2(u,n,CV1)
if n <= 0
  error("argument ''n'' must be an integer >= 1")
end
if CV1<= 0
  error("argument ''CV1'' must be > 0")
end
u (u <= 0) = 0;
 FCV2 = 1-ncfcdf(n./u,1,n-1,n/CV1^2);   
end