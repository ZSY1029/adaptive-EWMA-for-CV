function k=optAEWMACV(n,lambda,CV0,delta1,delta2,arl0)
%v(1)=lambda v(2)=k
if arl0<1
  error('argument ''arl0'' must be >= 1')
end
options = optimset('TolX',1e-5);
lb=0;
k0=6;
ub=12;
fun=@(k)confun(lambda,n,k,CV0,arl0,delta1);
[k,~]=fmincon(@(k)optUAEWMACVk(n,lambda,k,arl0,CV0,delta2),k0,[],[],[],[],lb,ub,fun,options);
%[k,~]=patternsearch(@(k)optUAEWMACVk(n,lambda,k,arl0,CV0,delta2),k0,[],[],[],[],lb,ub,fun,options);
%[k,~]=ga(@(k)optUAEWMACVk(n,lambda,k,arl0,CV0,delta2),1,[],[],[],[],lb,ub,fun,options);
%L0=3;
%L=fsolve(@(L)optUAEWMACV2L(n,lambda,k,L,CV0,arl0),L0,options);
end