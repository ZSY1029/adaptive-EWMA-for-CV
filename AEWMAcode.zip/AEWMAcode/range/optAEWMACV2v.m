function f=optAEWMACV2v(n,v,arl0,CV0,deltamin,deltamax)
if v(1)<=0 ||v(2)<=0
  f=100000;
else
  options = optimset('TolX',1e-5);
  L0=3;
  L=fsolve(@(L)optAEWMACV2L(n,v,L,CV0,arl0),L0,options);
  EARL1= EARLUAEWMACV2e(n,v,L,CV0,deltamin,deltamax);
  EARL0=ARLUAEWMACV2e(n,v,L,CV0,CV0);
  f=EARL1;
  Out=[v(1) v(2)*10 L EARL1 EARL0];
  fprintf('lam=%6.4f k=%6.4f L=%6.4f EARL1=%6.4f EARL0=%6.4f \n',Out);
end