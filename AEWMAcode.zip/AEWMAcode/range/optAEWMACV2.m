function v=optAEWMACV2(n,CV0,deltamin,deltamax,arl0)
%v(1)=lambda v(2)=k
if arl0<1
  error('argument ''arl0'' must be >= 1')
end
[mu0,sigma0]=musigmaCV2(n,CV0*deltamax);
k0=sigma0*0.5;
ku=2*(mu0+sigma0);
v0=[0.1 k0];
lb=[0.05,0];
ub=[0.5,ku];
options = optimset('TolX',1e-5);
[v,~]=patternsearch(@(v)optAEWMACV2v(n,v,arl0,CV0,deltamin,deltamax),v0,[],[],[],[],lb,ub,options);
%[v,~]=particleswarm(@(v)optAEWMACV2v(n,v,arl0,CV0,deltamin,deltamax),2,lb,ub);
%L0=3;
%L=fsolve(@(L)optAEWMACV2L(n,v,L,CV0,arl0),L0,options);
end