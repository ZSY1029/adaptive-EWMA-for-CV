%---------------------------------------------------------------%
function EARL = EARLUAEWMACV2(n,v,L,CV0,deltamin,deltamax)
[xi,wi] = GaussLagrange(15,deltamin,deltamax);
EARL = 0;
for il = 1:15
  xil = xi(il);
  wil = wi(il);
  CV1 = xil*CV0;
  ARL  = ARLUAEWMACV2e(n,v,L,CV0,CV1);%EARL
  EARL = EARL+ARL.*wil;
end
EARL= EARL/(deltamax-deltamin);
end