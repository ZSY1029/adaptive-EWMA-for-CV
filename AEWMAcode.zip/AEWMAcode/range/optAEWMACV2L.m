function f=optAEWMACV2L(n,v,L,CV0,arl0)
if L<=0
  f=100000;
else
  EARL0= ARLUAEWMACV2e(n,v,L,CV0,CV0);
  f=(arl0-EARL0)/arl0;
end