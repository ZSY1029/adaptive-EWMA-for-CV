function cv=ME(B,theta,eta,m,cv0,delta)
if m <= 0
  error("argument ''n'' must be an integer >= 1")
end
if cv0 <= 0
  error("argument ''CV0'' must be > 0")
end
cv=cv0*sqrt(B^2+eta^2/m)/(theta+B/delta);
end

