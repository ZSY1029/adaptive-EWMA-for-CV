function [mu0,sigma0] = musigmaCV2(n,B,theta,eta,m,cv0)
cv=ME(B,theta,eta,m,cv0,1);
mu0=cv^2*(1-3*cv^2/n);
sigma0=sqrt(cv^4*(2/(n-1)+cv^2*(4/n+20/(n*(n-1))+75*cv^2/n^2))-(mu0-cv^2)^2);
end