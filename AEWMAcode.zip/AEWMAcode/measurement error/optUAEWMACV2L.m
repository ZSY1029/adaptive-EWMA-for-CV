function f=optUAEWMACV2L(n,v,L,B,theta,eta,m,cv0,arl0)
if L<=0
  f=100000;
else
  EARL0= ARLUAEWMACV2(n,v,L,B,theta,eta,m,cv0,1);
  f=(arl0-EARL0)/arl0;
end