function FCV2 = cdfCV2(u,n,B,theta,eta,m,cv0,delta)
if n <= 0
  error("argument ''n'' must be an integer >= 1")
end
if delta<= 0
  error("argument ''delta'' must be > 0")
end
CV1=ME(B,theta,eta,m,cv0,delta);
u (u <= 0) = 0;
 FCV2 = 1-ncfcdf(n./u,1,n-1,n/CV1^2);   
end