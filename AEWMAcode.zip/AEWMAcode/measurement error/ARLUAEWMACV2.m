function [ARL,SDRL] = ARLUAEWMACV2(n,v,L,B,theta,eta,m,cv0,delta)
if n <= 1
  error("argument ''n'' must be an integer >= 2")
end
%if L <= 0
 % error("argument  ''L'' must be > 0")
%end
%if lambda <=0 || lambda > 1
  %error("argument ''lambda'' must be in (0,1]")
%end
if cv0 <= 0
  error("argument ''CV0'' must be > 0")
end
if delta < 1
  error("argument ''delta'' must be > =1")
end
s = 200;
[mu0CV2,sigma0CV2]=musigmaCV2(n,B,theta,eta,m,cv0);
lambda=v(1);
k=v(2)*sigma0CV2;
UCL = mu0CV2+L*sqrt(lambda/(2-lambda))*sigma0CV2;
LCL=mu0CV2;
d=(UCL-LCL)/(2*s);
Hj=[LCL,LCL+d:2*d:UCL-d];
Hi=Hj';
th=lambda*k;
Q0=mu0CV2-Hi(:,1);
Q1=Hj-Hi+d;
Q2=Hj-Hi-d;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fin_res01=find(Q0<-th);
fin_res02=find(abs(Q0)<th);
fin_res03=find(Q0>th);
Q0(fin_res01)=Q0(fin_res01)-(1-lambda)*k;
Q0(fin_res02)=Q0(fin_res02)/lambda;
Q0(fin_res03)=Q0(fin_res03)+(1-lambda)*k;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fin_res11=find(Q1<-th);
fin_res12=find(abs(Q1)<th);
fin_res13=find(Q1>th);
Q1(fin_res11)=Q1(fin_res11)-(1-lambda)*k;
Q1(fin_res12)=Q1(fin_res12)/lambda;
Q1(fin_res13)=Q1(fin_res13)+(1-lambda)*k;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fin_res21=find(Q2<-th);
fin_res22=find(abs(Q2)<th);
fin_res23=find(Q2>th);
Q2(fin_res21)=Q2(fin_res21)-(1-lambda)*k;
Q2(fin_res22)=Q2(fin_res22)/lambda;
Q2(fin_res23)=Q2(fin_res23)+(1-lambda)*k;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q=cdfCV2(Hi+Q1,n,B,theta,eta,m,cv0,delta)-cdfCV2(Hi+Q2,n,B,theta,eta,m,cv0,delta);
Q(:,1)=cdfCV2(Hi(:,1)+Q0,n,B,theta,eta,m,cv0,delta);
q=zeros(s+1,1);
q(1)=1;
I = eye(s+1,s+1);
W= (I-Q)^-1;
g = ones(s+1,1);
ARL=q'*W*g;
Z=q'*W*W*Q;
SDRL=sqrt(2*sum(Z)-ARL^2+ARL);