function v=optUAEWMACV2(n,B,theta,eta,m,cv0,deltamin,deltamax,arl0)
%v(1)=lambda v(2)=k
if arl0<1
  error('argument ''arl0'' must be >= 1')
end
v0=[0.1 6];
lb=[0.05,0];
ub=[0.5,12];
options = optimset('TolX',1e-5);
[v,~]=patternsearch(@(v)optUAEWMACV2v(n,v,arl0,B,theta,eta,m,cv0,deltamin,deltamax),v0,[],[],[],[],lb,ub,options);
end